//
//  customCell.swift
//  demoAlamofire
//
//  Created by user11 on 5/18/17.
//  Copyright © 2017 xyz. All rights reserved.
//

import UIKit

class customCell: UICollectionViewCell {
    
    @IBOutlet var imgView: UIImageView!
}
